import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("Heldnamen eingeben:");
		String heldn = scanner.next();
		System.out.println("Heldname: " + heldn);
		System.out.println("");

		Held held = new Held();
		int hph = held.hph;
		int angriff = held.angriff;
		int abwehr = held.abwehr;

		Schurke schurke = new Schurke();
		int hps = schurke.hps;
		int sangriff = schurke.sangriff;
		int armor = schurke.armor;

		int i = 0;
		int heldschaden = angriff - armor;
		int schurkeschaden = sangriff - abwehr;

		System.out.println("Der Kampf beginnt!");
		
		while (hph > 0) {

			if (hps <= 0) {
				if (i<1) {
					System.out.println("Das Spiel ist vorbei! \nVielen Dank Held " + heldn + ", du hast den Schurken besiegt!");
					i = i + 1;
				}
			}

			while (hps > 0) {
				System.out.println("Aktion eingeben, a für Angriff, b für Blockangriff:");
				System.out.println("");

				Scanner scanner2 = new Scanner(System.in);
				String aktion = scanner2.next();

				switch (aktion) {
				case "a":
					System.out.println("ANGRIFF!");
					hps = hps - heldschaden;
					System.out.println("Schurkenlebenspunkte:" + hps);
					hph = hph - schurkeschaden;
					System.out.println("Heldenlebenspunkte:" + hph);
					System.out.println("");
					break;

				case "b":
					System.out.println("BLOCKANGRIFF!");
					hps = hps - heldschaden;
					System.out.println("Schurkenlebenspunkte:" + hps);
					hph = hph - schurkeschaden + 5;
					System.out.println("Heldenlebenspunkte:" + hph);
					System.out.println("");
					break;

				}
			}
		}
	}
}
