import java.util.Scanner;

public class Schurke {

	int hps;
	int armor;
	int sangriff;

	public Schurke() {
		System.out.println("Schurkentyp eingeben:");

		Scanner scanner = new Scanner(System.in);
		int styp = scanner.nextInt();
		
		System.out.println("Schurkentyp: " + styp);
		System.out.println("");
		
		switch (styp) {
		case 1:
			hps = 60;
			armor = 5;
			sangriff = 10;
			break;
			
		case 2:
			hps = 30;
			armor = 2;
			sangriff = 15;
			break;
			
		case 3:
			hps = 45;
			armor = 3;
			sangriff = 12;
			break;

		}
	}
}