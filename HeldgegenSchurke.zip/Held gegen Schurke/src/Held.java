import java.util.Scanner;


public class Held {
    int hph;
    int abwehr;
    int angriff;
    
public Held(){
	System.out.println("Heldtyp eingeben:");
	
    Scanner scanner = new Scanner(System.in);
    int typ = scanner.nextInt();

    System.out.println("Heldtyp: " + typ);
    System.out.println("");

    switch (typ) {
        case 1:
            hph = 50;
            abwehr = 10;
            angriff = 25;
            break;

        case 2:
            hph = 75;
            abwehr = 5;
            angriff = 20;
            break;
            
        case 3:
            hph = 40;
            abwehr = 15;
            angriff = 35;
            break;
    }
}
} 
